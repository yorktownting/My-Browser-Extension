"use strict";

const defaults = { mode: "light", grayscaleMedia: false, hideAvatars: false };
const radios = [...document.querySelectorAll('input[name="mode"]')];
const media = document.querySelector("#grayscaleMedia");
const avatars = document.querySelector("#hideAvatars");
const status = document.querySelector("#status");
const themes = document.querySelector("#themes");

function render(settings) {
  const mode = radios.some(input => input.value === settings.mode) ? settings.mode : "light";
  for (const input of radios) input.checked = input.value === mode;
  media.checked = settings.grayscaleMedia === true;
  avatars.checked = settings.hideAvatars === true;
  media.disabled = mode === "original";
}

async function save(event) {
  const key = event.target.name === "mode" ? "mode" : event.target.id;
  const value = key === "mode" ? event.target.value : event.target.checked;
  media.disabled = radios.find(input => input.checked)?.value === "original";
  try {
    // Save only the edited setting to avoid overwriting changes from another popup.
    await chrome.storage.local.set({ [key]: value });
    status.textContent = "已保存，即时生效";
  } catch {
    status.textContent = "保存失败，请重新打开插件后重试";
  }
}

themes.disabled = true;
media.disabled = true;
avatars.disabled = true;
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (Object.keys(defaults).some(key => key in changes)) {
    chrome.storage.local.get(defaults).then(render).catch(() => {});
  }
});
chrome.storage.local.get(defaults).then(settings => {
  render(settings);
  themes.disabled = false;
  avatars.disabled = false;
  status.textContent = "仅在 stage1st.com 生效";
}).catch(() => {
  status.textContent = "无法读取设置，请重新加载插件";
});
for (const input of radios) input.addEventListener("change", save);
media.addEventListener("change", save);
avatars.addEventListener("change", save);
