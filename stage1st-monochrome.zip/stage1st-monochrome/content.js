(() => {
  "use strict";

  // Attribute-only changes: disabling the theme restores the site's own CSS.
  // Same-origin / about:blank editor frames receive these styles too.
  const defaults = { mode: "light", grayscaleMedia: false, hideAvatars: false };
  const modes = new Set(["light", "dark", "original"]);
  let state = { ...defaults };
  let revision = 0;

  function apply() {
    const root = document.documentElement;
    if (!root) return;
    root.toggleAttribute("data-s1-hide-avatars", state.hideAvatars);
    if (state.mode === "original") {
      root.removeAttribute("data-s1-mono");
      root.removeAttribute("data-s1-mono-media");
    } else {
      root.setAttribute("data-s1-mono", state.mode);
      root.toggleAttribute("data-s1-mono-media", state.grayscaleMedia);
    }
  }

  function update(values) {
    state = {
      mode: modes.has(values.mode) ? values.mode : defaults.mode,
      grayscaleMedia: values.grayscaleMedia === true,
      hideAvatars: values.hideAvatars === true
    };
    apply();
  }

  // Register before reading storage so changes cannot get lost during startup.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== "local") return;
    if (!Object.keys(defaults).some(key => key in changes)) return;
    revision += 1;
    const next = { ...state };
    for (const key of Object.keys(defaults)) {
      if (key in changes) next[key] = changes[key].newValue ?? defaults[key];
    }
    update(next);
  });

  const initialRevision = revision;
  chrome.storage.local.get(defaults).then(values => {
    if (revision === initialRevision) update(values);
  }).catch(() => apply());

  // document_start may run before <html> exists. No body scan is required;
  // CSS also covers rows, previews and dialogs appended later by Discuz.
  if (document.documentElement) {
    apply();
  } else {
    const observer = new MutationObserver(() => {
      if (document.documentElement) {
        apply();
        observer.disconnect();
      }
    });
    observer.observe(document, { childList: true });
  }
})();
